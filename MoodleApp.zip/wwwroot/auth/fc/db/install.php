<?php

function xmldb_auth_fc_install() {
    global $CFG, $DB;

}
