<?php

// index.php
