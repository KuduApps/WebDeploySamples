<?php

$module->version = 10; // Ignored, this should use $plugin
$plugin->version = 2013031900;
$plugin->component = 'local_foobar';
$plugin->requires = 2013031200;
$module->release = 'We are not an activity module!';
$plugin->maturity = MATURITY_ALPHA;
//$plugin->release = 'And this is commented';
