<?php

$plugin->component = 'local_one';
